package com.example.homeworkoutapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {
    private lateinit var toolbarHistoryActivity: Toolbar
    private lateinit var tvHistory: View
    private lateinit var rvHistory: RecyclerView
    private lateinit var tvNoDataAvailable: View
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        toolbarHistoryActivity = findViewById(R.id.toolbar_history_activity)
        tvHistory = findViewById(R.id.tvHistory)
        rvHistory = findViewById(R.id.rvHistory)
        tvNoDataAvailable = findViewById(R.id.tvNoDataAvailable)


        toolbarHistoryActivity.navigationIcon = ContextCompat.getDrawable(this, R.drawable.ic_back)
        toolbarHistoryActivity.setNavigationOnClickListener {
            onBackPressed() // Handle navigation as per your requirements
        }

        getAllCompletedDates()
    }
    private fun getAllCompletedDates() {
        val dbHandler = SqliteOpenHelper(this, null)
        val allCompletedDatesList = dbHandler.getAllCompletedDatesList()

        if (allCompletedDatesList.size > 0) {
            tvHistory.visibility = View.VISIBLE
            rvHistory.visibility = View.VISIBLE
            tvNoDataAvailable.visibility = View.GONE

            rvHistory.layoutManager = LinearLayoutManager(this)
            val historyAdapter = HistoryAdapter(this, allCompletedDatesList)
            rvHistory.adapter = historyAdapter
        } else {
            tvHistory.visibility = View.GONE
            rvHistory.visibility = View.GONE
            tvNoDataAvailable.visibility = View.VISIBLE
        }
    }
}