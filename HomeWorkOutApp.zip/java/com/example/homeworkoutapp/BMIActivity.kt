package com.example.homeworkoutapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.math.BigDecimal
import java.math.RoundingMode

class BMIActivity : AppCompatActivity() {
    private val METRIC_UNITS_VIEW = "METRIC_UNIT_VIEW"
    private val US_UNITS_VIEW = "US_UNIT_VIEW"
    private var currentVisibleView: String = METRIC_UNITS_VIEW

    private lateinit var toolbar: androidx.appcompat.widget.Toolbar
    private lateinit var calculateButton: Button
    private lateinit var metricHeightEditText: EditText
    private lateinit var metricWeightEditText: EditText
    private lateinit var usHeightFeetEditText: EditText
    private lateinit var usHeightInchEditText: EditText
    private lateinit var usWeightEditText: EditText
    private lateinit var displayResultLayout: View
    private lateinit var bmiValueTextView: TextView
    private lateinit var bmiTypeTextView: TextView
    private lateinit var bmiDescriptionTextView: TextView
    private lateinit var rgUnits: RadioGroup



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bmiactivity)

        toolbar = findViewById(R.id.toolbar_bmi_activity)
        calculateButton = findViewById(R.id.btnCalculateUnits)
        metricHeightEditText = findViewById(R.id.etMetricUnitHeight)
        metricWeightEditText = findViewById(R.id.etMetricUnitWeight)
        usHeightFeetEditText = findViewById(R.id.etUsUnitHeightFeet)
        usHeightInchEditText = findViewById(R.id.etUsUnitHeightInch)
        usWeightEditText = findViewById(R.id.etUsUnitWeight)
        displayResultLayout = findViewById(R.id.llDisplayBMIResult)
        bmiValueTextView = findViewById(R.id.tvBMIValue)
        bmiTypeTextView = findViewById(R.id.tvBMIType)
        bmiDescriptionTextView = findViewById(R.id.tvBMIDescription)
        rgUnits = findViewById(R.id.rgUnits)


        toolbar.navigationIcon = ContextCompat.getDrawable(this, R.drawable.ic_back)

        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        calculateButton.setOnClickListener {
            if (currentVisibleView == METRIC_UNITS_VIEW) {
                if (validateMetricUnits()) {
                    val heightValue: Float = metricHeightEditText.text.toString().toFloat() / 100
                    val weightValue: Float = metricWeightEditText.text.toString().toFloat()
                    val bmiValue = weightValue / (heightValue * heightValue)
                    displayBMIResult(bmiValue)
                } else {
                    Toast.makeText(this@BMIActivity, "Please enter valid values.", Toast.LENGTH_SHORT).show()
                }
            } else {
                if (validateUsUnits()) {
                    val usUnitHeightValueFeet: String = usHeightFeetEditText.text.toString()
                    val usUnitHeightValueInch: String = usHeightInchEditText.text.toString()
                    val usUnitWeightValue: Float = usWeightEditText.text.toString().toFloat()
                    val USheightValue = usUnitHeightValueInch.toFloat() + (usUnitHeightValueFeet.toFloat() * 12)
                    val bmiValue = 703 * (usUnitWeightValue / (USheightValue * USheightValue))
                    displayBMIResult(bmiValue)
                } else {
                    Toast.makeText(this@BMIActivity, "Please enter valid values.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        makeVisibleMetricUnitsView()

        rgUnits.setOnCheckedChangeListener { group, checkedId ->
            if (checkedId == R.id.rbMetricUnits) {
                makeVisibleMetricUnitsView()
            } else {
                makeVisibleUSUnitsView()
            }
        }
    }

    private fun makeVisibleMetricUnitsView() {
        currentVisibleView = METRIC_UNITS_VIEW
        metricWeightEditText.visibility = View.VISIBLE
        metricHeightEditText.visibility = View.VISIBLE
        metricHeightEditText.text?.clear()
        metricWeightEditText.text?.clear()
        usWeightEditText.visibility = View.GONE
        usHeightFeetEditText.visibility = View.GONE
        usHeightInchEditText.visibility = View.GONE
        displayResultLayout.visibility = View.INVISIBLE
    }

    private fun makeVisibleUSUnitsView() {
        currentVisibleView = US_UNITS_VIEW
        metricWeightEditText.visibility = View.GONE
        metricHeightEditText.visibility = View.GONE
        metricHeightEditText.text?.clear()
        metricWeightEditText.text?.clear()
        usWeightEditText.visibility = View.VISIBLE
        usHeightFeetEditText.visibility = View.VISIBLE
        usHeightInchEditText.visibility = View.VISIBLE
        displayResultLayout.visibility = View.INVISIBLE
    }


    private fun displayBMIResult(bmi: Float) {
        val bmiLabel: String
        val bmiDescription: String

        if (bmi.compareTo(15f) <= 0) {
            bmiLabel = "Very severely Underweight"
            bmiDescription = "You need to take more care of your health! Eat more!"
        } else if (bmi.compareTo(15f) > 0 && bmi.compareTo(16f) <= 0) {
            bmiLabel = "Severely underweight"
            bmiDescription = "You need to take care of your health! Eat more!"
        } else if (bmi.compareTo(16f) > 0 && bmi.compareTo(18.5f) <= 0) {
            bmiLabel = "Underweight"
            bmiDescription = "You need to take care of your health! Eat more!"
        } else if (bmi.compareTo(18.5f) > 0 && bmi.compareTo(25f) <= 0) {
            bmiLabel = "Normal"
            bmiDescription = "Congratulations! You are in a good fit shape!"
        } else if (bmi.compareTo(25f) > 0 && bmi.compareTo(30f) <= 0) {
            bmiLabel = "Overweight"
            bmiDescription = "Oops! need to take care of yourself! Workout more"
        } else if (bmi.compareTo(30f) > 0 && bmi.compareTo(35f) <= 0) {
            bmiLabel = "Obese Class | (Moderately obese)"
            bmiDescription = "Oops! You really need to take care of your health! Workout daily"
        } else if (bmi.compareTo(35f) > 0 && bmi.compareTo(40f) <= 0) {
            bmiLabel = "Obese Class || (Severely obese)"
            bmiDescription = "Oops! Your health is in a very dangerous condition! Act now!"
        } else {
            bmiLabel = "Obese Class ||| (Very Severweight)"
            bmiDescription = "OMG! You are in a very dangerous condition! Act now!"
        }

        displayResultLayout.visibility = View.VISIBLE
        val bmiValue = BigDecimal(bmi.toDouble()).setScale(2, RoundingMode.HALF_EVEN).toString()
        bmiValueTextView.text = bmiValue
        bmiTypeTextView.text = bmiLabel
        bmiDescriptionTextView.text = bmiDescription
    }

    private fun validateMetricUnits(): Boolean {
        if (metricWeightEditText.text.toString().isEmpty() || metricHeightEditText.text.toString().isEmpty()) {
            return false
        }
        return true
    }

    private fun validateUsUnits(): Boolean {
        if (usHeightFeetEditText.text.toString().isEmpty() || usHeightInchEditText.text.toString().isEmpty() || usWeightEditText.text.toString().isEmpty()) {
            return false
        }
        return true
    }
}
