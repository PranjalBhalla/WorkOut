package com.example.homeworkoutapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    private lateinit var llStart: LinearLayout
    private lateinit var llBMI: LinearLayout
    private lateinit var llHistory: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        llStart = findViewById(R.id.llStart)
        llBMI = findViewById(R.id.llBMI)
        llHistory = findViewById(R.id.llHistory)

        //on clicking the Start button
        llStart.setOnClickListener {
            val intent = Intent(this@MainActivity, ExerciseActivity::class.java)
            startActivity(intent)
        }

        //on clicking the BMI calculator button
        llBMI.setOnClickListener {
            val intent = Intent(this@MainActivity, BMIActivity::class.java)
            startActivity(intent)
        }

        //on clicking History button
        llHistory.setOnClickListener {
            val intent = Intent(this@MainActivity, HistoryActivity::class.java)
            startActivity(intent)
        }



    }

}