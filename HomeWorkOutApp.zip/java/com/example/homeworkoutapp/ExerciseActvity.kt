package com.example.homeworkoutapp

import android.app.Dialog
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.CountDownTimer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class ExerciseActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private var restTimer: CountDownTimer? = null
    private var exerciseTimer: CountDownTimer? = null
    private var tts: TextToSpeech? = null
    private var player: MediaPlayer? = null
    private var exerciseAdapter: ExerciseStatusAdapter? = null
    private var exerciseList: ArrayList<ExerciseModel>? = null
    private var currentExercisePosition = 0

    private lateinit var toolbarExercise: androidx.appcompat.widget.Toolbar
    private lateinit var progressBar: ProgressBar
    private lateinit var tvTimer: TextView
    private lateinit var tvUpcomingExerciseName: TextView
    private lateinit var llRestView: View
    private lateinit var llExerciseView: View
    private lateinit var progressBarExercise: ProgressBar
    private lateinit var tvExerciseTimer: TextView
    private lateinit var ivImage: ImageView
    private lateinit var tvExerciseName: TextView
    private lateinit var rvExerciseStatus: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exercise_actvity)

        player = MediaPlayer.create(applicationContext, R.raw.background)
        setupViews()
        setupListeners()
        exerciseList = Constants.defaultExerciseList()
        setupRestView()
        setupExerciseStatusRecyclerView()
        player?.start()
    }

    override fun onDestroy() {
        restTimer?.cancel()
        exerciseTimer?.cancel()
        tts?.stop()
        tts?.shutdown()
        player?.stop()
        player?.release()
        super.onDestroy()
    }

    private fun setupViews() {
        toolbarExercise = findViewById(R.id.toolbar_exercise_activity)
        progressBar = findViewById(R.id.progressBar)
        tvTimer = findViewById(R.id.tvTimer)
        tvUpcomingExerciseName = findViewById(R.id.tvUpcomingExerciseName)
        llRestView = findViewById(R.id.llRestView)
        llExerciseView = findViewById(R.id.llExerciseView)
        progressBarExercise = findViewById(R.id.progressBarExercise)
        tvExerciseTimer = findViewById(R.id.tvExerciseTimer)
        ivImage = findViewById(R.id.ivImage)
        tvExerciseName = findViewById(R.id.tvExerciseName)
        rvExerciseStatus = findViewById(R.id.rvExerciseStatus)
    }

    private fun setupListeners() {
        toolbarExercise.navigationIcon = ContextCompat.getDrawable(this, R.drawable.ic_back_black)
        toolbarExercise.setNavigationOnClickListener {
            customDialogForBackButton()
        }

        tts = TextToSpeech(this, this)
    }

    private fun customDialogForBackButton() {
        val customDialog = Dialog(this)
        customDialog.setContentView(R.layout.custom_dialog_for_exit)
        customDialog.findViewById<View>(R.id.tvYes).setOnClickListener {
            finish()
            customDialog.dismiss()
        }
        customDialog.findViewById<View>(R.id.tvNo).setOnClickListener {
            customDialog.dismiss()
        }
        customDialog.show()
    }

    private fun setupRestView() {
        llRestView.visibility = View.VISIBLE
        llExerciseView.visibility = View.GONE
        restTimer?.cancel()
//        val restTimerDuration: Long = 2
        val upcomingExercise = exerciseList?.get(currentExercisePosition)
        tvUpcomingExerciseName.text = upcomingExercise?.getName()
        setRestProgressBar()
    }

    private fun setupExerciseView() {
        llRestView.visibility = View.GONE
        llExerciseView.visibility = View.VISIBLE
        exerciseTimer?.cancel()
//        val exerciseTimerDuration: Long = 2
        val currentExercise = exerciseList?.get(currentExercisePosition)
        ivImage.setImageResource(currentExercise?.getImage() ?: 0)
        tvExerciseName.text = currentExercise?.getName()
        val upcomingExercise = exerciseList?.get(currentExercisePosition)
        tvUpcomingExerciseName.text = upcomingExercise?.getName()
        speakOut(upcomingExercise?.getName() ?: "")
        setExerciseProgressBar()
    }

    private fun setRestProgressBar() {
        val restTimerDuration: Long = 2
        progressBar.progress = 0
        restTimer = object : CountDownTimer(restTimerDuration * 1000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                progressBar.progress = (restTimerDuration - millisUntilFinished / 1000).toInt()
                tvTimer.text = (millisUntilFinished / 1000).toString()
            }

            override fun onFinish() {
                exerciseList?.get(currentExercisePosition)?.setIsSelected(true)
                exerciseAdapter?.notifyDataSetChanged()
                setupExerciseView()
            }
        }.start()
    }

    private fun setExerciseProgressBar() {
        val exerciseTimerDuration: Long = 2
        progressBarExercise.progress = 0
        exerciseTimer = object : CountDownTimer(exerciseTimerDuration * 1000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                progressBarExercise.progress = (exerciseTimerDuration - millisUntilFinished / 1000).toInt()
                tvExerciseTimer.text = (millisUntilFinished / 1000).toString()
            }

            override fun onFinish() {
                if (currentExercisePosition < exerciseList?.size!! - 1) {
                    exerciseList!![currentExercisePosition].setIsSelected(false)
                    exerciseList!![currentExercisePosition].setIsCompleted(true)
                    exerciseAdapter?.notifyDataSetChanged()
                    currentExercisePosition++
                    setupRestView()
                } else {
                    finish()
                    val intent = Intent(this@ExerciseActivity, FinishActvity::class.java)
                    startActivity(intent)
                    player?.stop()
                }
            }
        }.start()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "Language specified is not supported")
                Toast.makeText(this, "Language not Supported", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun speakOut(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "")
    }

    private fun setupExerciseStatusRecyclerView() {
        rvExerciseStatus.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        exerciseAdapter = ExerciseStatusAdapter(this, (exerciseList ?: emptyList()) as ArrayList<ExerciseModel>
        )
        rvExerciseStatus.adapter = exerciseAdapter
    }
}
