package com.example.homeworkoutapp

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class FinishActvity : AppCompatActivity() {
    private lateinit var toolbarFinishActivity: Toolbar
    private lateinit var btnFinish: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finish_actvity)
        toolbarFinishActivity = findViewById(R.id.toolbar_finish_activity)
        btnFinish = findViewById(R.id.btnFinish)

        toolbarFinishActivity.navigationIcon = ContextCompat.getDrawable(this, R.drawable.ic_back_black)

        toolbarFinishActivity.setNavigationOnClickListener {
            onBackPressed()
        }

        btnFinish.setOnClickListener {

            finish()
        }

        //on finishing the workout, calling the addDateToDatabase() to add the date and time in the database
        addDateToDatabase()
    }
    //method for adding date to the database and formatting the date format
    private fun addDateToDatabase() {
        val calendar = Calendar.getInstance()
        val dateTime = calendar.time
        Log.i("DATE:", "" + dateTime)//making a log entry for testing

        val sdf = SimpleDateFormat("dd-MMM-yyyy         HH:mm:ss aaa", Locale.getDefault())//formatting date and time
        val date = sdf.format(dateTime)

        val dbHandler = SqliteOpenHelper(this, null)
        dbHandler.addDate(date)
        Log.i("DATE: ", "Added")
    }
}